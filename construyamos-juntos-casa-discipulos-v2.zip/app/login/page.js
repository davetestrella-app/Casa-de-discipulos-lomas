"use client";
import { useState } from "react";
import { getSupabase } from "../../lib/supabase";

export default function Login(){
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState(""); const [loading,setLoading]=useState(false);
  async function submit(e){e.preventDefault();setLoading(true);setMessage(""); const supabase=getSupabase(); if(!supabase){setMessage("Configura las variables de Supabase para activar el acceso.");setLoading(false);return;} const {error}=await supabase.auth.signInWithPassword({email,password}); if(error)setMessage(error.message); else window.location.href="/admin";setLoading(false);}
  return <main className="auth"><div className="authCard"><div className="eyebrow">CASA DE DISCÍPULOS</div><h1>Panel de administración</h1><p>Acceso privado para actualizar el avance de la campaña.</p><form onSubmit={submit}><input type="email" placeholder="Correo" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Contraseña" value={password} onChange={e=>setPassword(e.target.value)} required/><button disabled={loading}>{loading?"Entrando…":"Entrar"}</button></form>{message&&<div className="notice">{message}</div>}<a href="/">← Volver al sitio</a></div></main>
}
