import Image from "next/image";
import { META, WHATSAPP, DEMO, money } from "../lib/config";
import { getSupabase } from "../lib/supabase";

export const revalidate = 30;

async function getStats() {
  const supabase = getSupabase();
  if (!supabase) return DEMO;
  const { data, error } = await supabase.rpc("public_campaign_stats");
  if (error || !data) return DEMO;
  return data;
}

export default async function Home() {
  const stats = await getStats();
  const progress = Math.min((Number(stats.total || 0) / META) * 100, 100);
  const rounded = Math.round(progress * 10) / 10;
  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#inicio"><Image src="/images/logo-la-alianza.png" alt="La Alianza" width={50} height={50}/><span><b>CONSTRUYAMOS JUNTOS</b><em>La Casa de Discípulos</em></span></a>
        <div className="navLinks"><a href="#vision">Visión</a><a href="#participa">Participa</a><a href="#avance">Avance</a></div>
        <a className="navCta" href={WHATSAPP} target="_blank">Quiero construir</a>
      </nav>

      <section id="inicio" className="hero">
        <div className="heroCopy">
          <div className="eyebrow">LOMAS DE GRANADA · POPAYÁN · 2026</div>
          <h1>Una casa para formar <em>discípulos que hacen discípulos.</em></h1>
          <p className="lead">Hoy nos reunimos donde podemos. Estamos creyendo por un lugar propio para discipular, servir a Lomas y enviar nuevas generaciones.</p>
          <div id="avance" className="progressCard">
            <div className="progressHead"><div><small>FONDO CASA DE DISCÍPULOS</small><strong>{money(stats.total)}</strong></div><b>{rounded}%</b></div>
            <div className="bar"><span style={{width:`${progress}%`}}/></div>
            <div className="progressMeta"><span>Meta inicial <b>{money(META)}</b></span><span>{Number(stats.contributors || 0)} personas/familias</span></div>
            <div className="miniStats"><div><b>{money(stats.families)}</b><span>Familias</span></div><div><b>{money(stats.course)}</b><span>Curso</span></div><div><b>{money(stats.builders)}</b><span>Constructores</span></div></div>
          </div>
          <div className="actions"><a className="primary" href={WHATSAPP} target="_blank">Quiero ser parte <span>→</span></a><a className="secondary" href="#vision">Conocer la visión</a></div>
        </div>
        <div className="heroVisual"><Image src="/images/reunion-3.jpeg" alt="Comunidad de La Alianza reunida" fill priority sizes="(max-width:900px) 100vw, 52vw"/><div className="photoTag"><b>La Casa ya comenzó.</b><span>Está en cada discípulo.</span></div></div>
      </section>

      <section id="vision" className="section white">
        <div className="intro"><div className="eyebrow">LA VISIÓN</div><h2>Primero conseguimos la tierra. <em>Después construiremos juntos.</em></h2><p>Queremos adquirir un terreno amplio que permita crecer por etapas: comenzar con un espacio para 100–200 personas y avanzar hacia una Casa de Discípulos con capacidad para más de 1.000.</p></div>
        <div className="steps"><article><span>01</span><h3>La tierra</h3><p>Un terreno de aproximadamente 1.000–1.500 m², pensado desde el inicio para el crecimiento.</p></article><article><span>02</span><h3>La primera casa</h3><p>Auditorio inicial, discipulado, niños, recepción y servicios para una comunidad de 100–200 personas.</p></article><article><span>03</span><h3>La visión completa</h3><p>Una casa que forme, envíe y multiplique discípulos para Lomas, Popayán y nuevas generaciones.</p></article></div>
      </section>

      <section className="story"><div className="storyImg"><Image src="/images/reunion-1.jpeg" alt="Reunión de discipulado" fill sizes="(max-width:800px) 100vw, 50vw"/></div><div className="storyCopy"><div className="eyebrow">ESTO YA ESTÁ SUCEDIENDO</div><h2>La Casa no empieza cuando compremos el terreno.</h2><p>Ya existe en cada mesa, cada conversación, cada familia y cada discípulo que decide seguir a Jesús y ayudar a otra persona a seguirlo.</p><blockquote>“La iglesia no es un lugar al que vamos; es una familia a la que pertenecemos.”</blockquote></div></section>

      <section id="participa" className="section cream"><div className="intro center"><div className="eyebrow">TRES FORMAS DE CONSTRUIR</div><h2>¿Cómo quieres construir?</h2><p>Todos podemos ser parte. No importa el tamaño de la semilla; importa que juntos hagamos posible la visión.</p></div><div className="cards">
        <a className="card" href={WHATSAPP} target="_blank"><span>01</span><h3>Una familia, una semilla</h3><p>Aporta semanalmente al Fondo Casa de Discípulos según lo que Dios ponga en tu corazón.</p><b>Quiero aportar →</b></a>
        <a className="card" href={WHATSAPP} target="_blank"><span>02</span><h3>Forma un discípulo</h3><p>Conoce nuestro curso sobre el modelo de Jesús para hacer discípulos. Tu inscripción también se convierte en una semilla.</p><b>Quiero conocer el curso →</b></a>
        <a className="card" href={WHATSAPP} target="_blank"><span>03</span><h3>Conviértete en constructor</h3><p>Si quieres hacer un aporte significativo o conectar la visión con otros aliados, queremos hablar contigo.</p><b>Quiero conocer la visión →</b></a>
      </div></section>

      <section className="gallery"><div><Image src="/images/reunion-2.jpeg" alt="Comunidad" fill sizes="33vw"/></div><div><Image src="/images/reunion-1.jpeg" alt="Discipulado" fill sizes="33vw"/></div><div><Image src="/images/reunion-3.jpeg" alt="Familias" fill sizes="33vw"/></div></section>

      <section className="final"><div className="eyebrow">CONSTRUYAMOS JUNTOS · 2026</div><h2>La visión es grande.<br/><em>Pero juntos podemos construirla.</em></h2><p>Primero, la tierra. Después, la Casa. Siempre, los discípulos.</p><a className="primary" href={WHATSAPP} target="_blank">Quiero construir la Casa →</a></section>
      <footer><div><Image src="/images/logo-la-alianza.png" alt="La Alianza" width={40} height={40}/><span>La Alianza · Caminando con Jesús</span></div><span>Casa de Discípulos · Lomas de Granada · Popayán</span></footer>
    </main>
  );
}
