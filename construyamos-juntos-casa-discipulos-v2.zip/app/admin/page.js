"use client";
import { useEffect,useState } from "react";
import { getSupabase } from "../../lib/supabase";
import { META,money } from "../../lib/config";

export default function Admin(){
 const [session,setSession]=useState(null),[stats,setStats]=useState(null),[form,setForm]=useState({amount:"",category:"families",note:""}),[msg,setMsg]=useState(""),[loading,setLoading]=useState(true);
 const supabase=getSupabase();
 useEffect(()=>{if(!supabase){setLoading(false);return;} supabase.auth.getSession().then(({data})=>{setSession(data.session);setLoading(false);if(data.session)load();});},[]);
 async function load(){const {data}=await supabase.rpc("admin_campaign_stats");if(data)setStats(data);}
 async function add(e){e.preventDefault();setMsg("");const amount=Number(form.amount);if(!amount||amount<1)return setMsg("Ingresa un valor válido.");const {error}=await supabase.from("contributions").insert({amount,category:form.category,note:form.note||null});if(error)setMsg(error.message);else{setForm({amount:"",category:"families",note:""});setMsg("Aporte registrado correctamente.");load();}}
 async function logout(){await supabase.auth.signOut();window.location.href="/login";}
 if(loading)return <main className="auth"><div className="authCard"><p>Cargando…</p></div></main>;
 if(!supabase||!session)return <main className="auth"><div className="authCard"><div className="eyebrow">ACCESO PRIVADO</div><h1>Panel no disponible</h1><p>Configura Supabase y crea el usuario administrador para activar este panel.</p><a className="primary inline" href="/login">Ir al acceso</a></div></main>;
 const total=Number(stats?.total||0),progress=Math.min(total/META*100,100);
 return <main className="admin"><header><div><div className="eyebrow">CASA DE DISCÍPULOS</div><h1>Panel de campaña</h1></div><div><a href="/">Ver sitio</a><button className="ghost" onClick={logout}>Salir</button></div></header><section className="adminGrid"><div className="adminMain"><div className="adminHero"><span>RECAUDADO</span><strong>{money(total)}</strong><div className="bar"><span style={{width:`${progress}%`}}/></div><small>{progress.toFixed(1)}% de {money(META)}</small></div><div className="adminCards"><div><b>{money(stats?.families||0)}</b><span>Familias</span></div><div><b>{money(stats?.course||0)}</b><span>Curso</span></div><div><b>{money(stats?.builders||0)}</b><span>Constructores</span></div></div></div><form className="adminForm" onSubmit={add}><div className="eyebrow">REGISTRAR APORTE</div><h2>Nuevo aporte confirmado</h2><label>Valor<input type="number" min="1" step="1000" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} placeholder="50000" required/></label><label>Frente<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option value="families">Familias</option><option value="course">Curso</option><option value="builders">Constructores</option></select></label><label>Nota<input value={form.note} onChange={e=>setForm({...form,note:e.target.value})} placeholder="Ej. aporte semanal"/></label><button>Guardar aporte</button>{msg&&<div className="notice">{msg}</div>}</form></section></main>
}
