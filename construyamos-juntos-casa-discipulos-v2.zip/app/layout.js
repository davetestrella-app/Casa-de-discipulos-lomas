import "./globals.css";

export const metadata = {
  title: "Construyamos Juntos | La Casa de Discípulos",
  description: "La Casa de Discípulos de La Alianza en Lomas de Granada, Popayán.",
};

export default function RootLayout({ children }) {
  return <html lang="es"><body>{children}</body></html>;
}
