# Construyamos Juntos — Casa de Discípulos · V2

Plataforma para la campaña de La Alianza en Lomas de Granada, Popayán.

## Incluye
- Landing institucional responsive.
- Contador de meta de $120.000.000 COP.
- Estadísticas por frente: familias, curso y constructores.
- CTA directo a WhatsApp +57 321 792 9578.
- Supabase opcional: base de datos, funciones públicas agregadas y autenticación.
- `/login` y `/admin` para registrar aportes confirmados sin tocar código.
- SQL de Supabase en `supabase/schema.sql`.

## Ejecutar
```bash
npm install
cp .env.example .env.local
npm run dev
```
Sin Supabase configurado, el sitio funciona en modo demostración con $0.

## Activar Supabase
1. Crea un proyecto en Supabase.
2. Copia URL y anon key a `.env.local`.
3. Ejecuta `supabase/schema.sql` en el SQL Editor.
4. En Authentication crea el usuario administrador.
5. En Vercel agrega las mismas variables de entorno.

## Deploy en Vercel
Importa el repositorio desde GitHub. Framework: Next.js. Build command: `next build`.

## Próximas mejoras
- Registro público de compromisos/aportes con comprobante.
- QR y pasarela de pagos.
- Timeline público de avances.
- Módulo del curso El Camino del Discípulo.
- Dashboard con gráficos mensuales.
- Roles para varios administradores.
