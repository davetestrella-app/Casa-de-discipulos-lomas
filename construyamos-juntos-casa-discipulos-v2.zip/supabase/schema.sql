-- CONSTRUYAMOS JUNTOS · SUPABASE
create extension if not exists pgcrypto;

create table if not exists public.contributions (
  id uuid primary key default gen_random_uuid(),
  amount bigint not null check (amount > 0),
  category text not null check (category in ('families','course','builders')),
  note text,
  created_at timestamptz not null default now()
);

alter table public.contributions enable row level security;

-- Public users only need aggregated totals, never individual contributions.
create or replace function public.public_campaign_stats()
returns json
language sql
security definer
set search_path = public
as $$
  select json_build_object(
    'total', coalesce(sum(amount),0),
    'families', coalesce(sum(amount) filter (where category='families'),0),
    'course', coalesce(sum(amount) filter (where category='course'),0),
    'builders', coalesce(sum(amount) filter (where category='builders'),0),
    'contributors', count(*)
  ) from public.contributions;
$$;

grant execute on function public.public_campaign_stats() to anon, authenticated;

-- Admin-only writes. Supabase Auth users are the administrators.
create policy "authenticated can insert contributions"
on public.contributions for insert to authenticated
with check (true);

create policy "authenticated can read contributions"
on public.contributions for select to authenticated
using (true);

create or replace function public.admin_campaign_stats()
returns json
language sql
security invoker
set search_path = public
as $$
  select json_build_object(
    'total', coalesce(sum(amount),0),
    'families', coalesce(sum(amount) filter (where category='families'),0),
    'course', coalesce(sum(amount) filter (where category='course'),0),
    'builders', coalesce(sum(amount) filter (where category='builders'),0)
  ) from public.contributions;
$$;

grant execute on function public.admin_campaign_stats() to authenticated;
